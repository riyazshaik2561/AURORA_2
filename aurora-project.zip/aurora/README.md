# Aurora Landing Page

Vite + React 19 + TypeScript + Tailwind CSS v4 + Framer Motion.

## Run locally

1. Install Node.js (a current LTS release).
2. Extract this ZIP and open a terminal in the `aurora` folder.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL printed by Vite.

## Production build

Run `npm run build`; then `npm run preview` to preview the built site.

## Background video

Asset status during ZIP creation: could not download in this environment (URLError)

The page expects the video at `public/hero.mp4`. If it is not included, download the original from:
https://pub-1e5b4001b36b47e28e6a2fb775966a79.r2.dev/templates/aurora/hero.mp4
and save it as `public/hero.mp4`.
