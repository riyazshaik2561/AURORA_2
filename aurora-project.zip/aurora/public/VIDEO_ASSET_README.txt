The original hero video could not be downloaded during ZIP creation.
Download it from:
https://pub-1e5b4001b36b47e28e6a2fb775966a79.r2.dev/templates/aurora/hero.mp4
Save the file as public/hero.mp4. The page references /hero.mp4.
